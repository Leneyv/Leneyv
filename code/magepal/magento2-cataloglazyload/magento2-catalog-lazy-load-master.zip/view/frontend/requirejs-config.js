/**
 * Copyright © MagePal LLC. All rights reserved.
 * See COPYING.txt for license details.
 * https://www.magepal.com | support@magepal.com
 */

var config = {
    map: {
        '*': {
            MagePalLazyLoad: 'MagePal_CatalogLazyLoad/js/lazyload'
        }
    }
};
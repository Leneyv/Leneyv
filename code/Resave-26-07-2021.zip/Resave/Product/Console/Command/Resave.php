<?php
declare(strict_types=1);

namespace Resave\Product\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\App\{ObjectManager, State};


class Resave extends Command
{

    const NAME_ARGUMENT = "name";
    const NAME_OPTION = "option";
    protected $objectManager;
    protected $state;

     public function __construct()
    {
        $this->objectManager = ObjectManager::getInstance();
        $this->state = $state;

        parent::__construct();
    }
    /**
     * {@inheritdoc}
     */
    protected function execute(
        InputInterface $input,
        OutputInterface $output
    ) { 
        $name = $input->getArgument(self::NAME_ARGUMENT);
        $option = $input->getOption(self::NAME_OPTION);
        
        $productCollectionFactory = $this->objectManager->get('\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory'); 
        $productcollection = $productCollectionFactory->create()->addAttributeToSelect('*')
                            ->addAttributeToFilter('entity_id', array( 'from' => $name))
                            ->load();
         $output->writeln("Total Products".$productcollection->getSize().'\r');
        foreach ($productcollection as $product) {
            $productId = $product->getId();
            $product = $this->objectManager->create('Magento\Catalog\Model\Product');
            $product->load($productId); 
            $product->save(); 
            $output->writeln("product saved successfully -".$productId.'\r');
        }
        $output->writeln("successfully End ");
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->setName("resave_product:resave");
        $this->setDescription("resave product");
        $this->setDefinition([
            new InputArgument(self::NAME_ARGUMENT, InputArgument::OPTIONAL, "Name"),
            new InputOption(self::NAME_OPTION, "-a", InputOption::VALUE_NONE, "Option functionality")
        ]);
        parent::configure();
    }
}


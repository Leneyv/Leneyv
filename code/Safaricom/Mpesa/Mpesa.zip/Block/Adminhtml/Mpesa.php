<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/3/2018
 * Time: 12:36 PM
 */


namespace Safaricom\Mpesa\Block\Adminhtml;

use \Magento\Backend\Block\Widget\Grid\Container;

class Mpesa extends Container
{
    public function _construct()
    {
        parent::_construct();
    }
}
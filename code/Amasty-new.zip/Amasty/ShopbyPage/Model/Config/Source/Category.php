<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_ShopbyPage
 */


namespace Amasty\ShopbyPage\Model\Config\Source;

/**
 * Class Category
 *
 * @package Amasty\ShopbyPage\Model\Config\Source
 */
class Category extends \Amasty\Shopby\Model\Source\Category
{
}

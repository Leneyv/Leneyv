var config = {
    map: {
        '*': {
            ibnabmodernizr:       'Ibnab_MegaMenu/js/modernizr-2.8.3',
        }
    }
}

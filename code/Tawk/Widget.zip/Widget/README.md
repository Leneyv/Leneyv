Magento Tawk.to Live Chat Module

This module adds Tawk.to Live Chat to your Magento 2 site.

To install and set up your tawk.to account, please follow this documentation https://www.tawk.to/knowledgebase/plugins-and-modules/magento-2-integration/